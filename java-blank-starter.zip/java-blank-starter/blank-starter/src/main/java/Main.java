import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.util.*;

public class Main {

    // <property_value, <property_key, object_reference>>
    private static Map<String, Map<String, List<Map>>> personsByValue = new HashMap<>();
    private static Map<String, Map<String, List<Map>>> vehiclesByValue = new HashMap<>();
    private static Map<String, Map<String, List<Map>>> casesByValue = new HashMap<>();

    private static void parseDataFile() {
        ObjectMapper ob = new ObjectMapper();
        File file = new File("src\\main\\java\\entities.json");

        List<Map> data = null;
        try {
            data = ob.readValue(file, List.class);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        Map<String, Map<String, List<Map>>> personsByValue = new HashMap<>();
        Map<String, Map<String, List<Map>>> vehiclesByValue = new HashMap<>();
        Map<String, Map<String, List<Map>>> casesByValue = new HashMap<>();

        for(Map obj : data) {
            String model = (String) obj.get("model");
            if(model.equals("person")) {
                putObjByValue(personsByValue, obj);
            } else if(model.equals("vehicle")) {
                putObjByValue(vehiclesByValue, obj);
            } else if(model.equals("case")) {
                putObjByValue(casesByValue, obj);
            }
        }
    }

    private static void putObjByValue(Map<String, Map<String, List<Map>>> objectsByType, Map object) {
        List properties = (List) object.get("properties");
        for(Object p : properties) {
            Map<String, String> kv = (Map<String, String>) p;
            String slug = kv.get("slug");

            String value = String.valueOf(kv.get("value"));

            Map<String, List<Map>> objectsByValue = objectsByType.getOrDefault(slug, new HashMap<>());
            List<Map> objects = objectsByValue.getOrDefault(value, new ArrayList<Map>());

            objects.add(object);
            objectsByValue.put(value, objects);
            objectsByType.put(slug, objectsByValue);
        }
    }

    public static void main(String[] args) throws Exception{
        String cmd1 = "--models person";
        Map<String, List<String>> filters = parseCommand(cmd1);

//        String model = filters.get("model");


    }

    private static Map<String, List<String>> parseCommand(String cmd) {
        String[] args = cmd.split(" ");
        Map<String, List<String>> filters = new HashMap<>();
        filters.put("model", new ArrayList<>());
        filters.put("property", new ArrayList<>());

        for(int i=0; i<args.length; i++) {
            if(args[i].equals("--models")) {
                for(String model : args[i+1].split(",")) {
                    filters.get("model").add(model);
                }
            }
            else if(args[i].equals("--properties")) {
                String[] kv = args[i+1].split(":");
                filters.get("property").add(kv[0]);
                for(String value : kv[1].split(",")) {
                    filters.get("property").add(value);
                }
            }
        }

        return filters;
    }
}
